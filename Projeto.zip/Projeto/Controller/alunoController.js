const alunoNegocio = require('../negocio/aluno_negocio.js')

exports.inserir = (req, res) => {
    const aluno = req.body;
    alunoNegocio.inserir(aluno, 
        function(err, alunoCadastrado) {
          if(err){
            res.status(500).json({'Erro' :err});
          }
          else {
            res.status(201).json(alunoCadastrado);
          }
        });    
}

exports.listar = (req, res) => {
    alunoNegocio.listar(function (err, aluno){
    if(err){
        res.status(500).json({'Erro' :err});
    }else{
        res.json(aluno);
    }
  })
}

exports.buscarPorMatricula = (req, res) => {
  const matricula = req.params.matricula;

    alunoNegocio.buscarPorMatricula(matricula, function (err, aluno){
      if(err) {
        res.status(err.numero).json({erro: err.mensagem});
      }
      else {
        res.json(aluno);
      }
    });
}

exports.deletar = (req, res) => {
  const matricula = req.params.matricula;
    alunoNegocio.deletar(matricula, function (err, aluno){
        if(err) {
          res.status(err.numero).json({erro: err.mensagem});
        }
        else {
          res.json(aluno);
        }
      });  
}

exports.atualizar = (req, res) => {
  const matricula = req.params.matricula;
  const aluno = req.body;
  alunoNegocio.atualizar(matricula, aluno, 
    function(err, alunoAtualizado) {
      if(err){
        res.status(err.numero).json({erro: err.mensagem});
      }
      else {
        res.json(alunoAtualizado);
      }
    });
}

