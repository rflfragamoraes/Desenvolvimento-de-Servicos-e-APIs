const livroNegocio = require('../negocio/livro_negocio.js')

exports.inserir = (req, res) => {
    const livro = req.body;
    livroNegocio.inserir(livro, 
        function(err, livroCadastrado) {
          if(err){
            res.status(500).json({'Erro' :err});
          }
          else {
            res.status(201).json(livroCadastrado);
          }
        });  
  }

exports.listar = (req, res) => {
    livroNegocio.listar(function (err, livro){
        if(err){
            res.json({'Erro' :err});
        }else{
            res.json(livro);
        }
      })
  }

  exports.deletar = (req, res) => {
    const codigo = req.params.codigo;
    livroNegocio.deletar(codigo, function (err, livro){
        if(err) {
          res.status(err.numero).json({erro: err.mensagem});
        }
        else {
          res.json(livro);
        }
      }); 
}