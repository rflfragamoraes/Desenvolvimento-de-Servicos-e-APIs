const {Client} = require('pg');

const erroBancoDados = { 
    mensagem: "Erro de conexao no BD",
    numero: 500
};

const erroAlunoNaoEncontrado = {
    mensagem: "Aluno nao encontrado",
    numero: 404
};

const conexao = {
    host: 'localhost',
    port: 5432,
    user: 'postgres',
    password: 'postgres',
    database: 'crud_biblioteca'
};

// Listar
function listar(callback) {
    const cliente = new Client(conexao);
    cliente.connect();
    
    const sql = "SELECT * FROM tabela_aluno";
    cliente.query(sql, 
        function (err, res) {
            if(err) {
                console.log(err);
                callback(erroBancoDados, undefined);
            }
            else {
                let aluno = res.rows;
                callback(undefined, aluno);     
            }
            cliente.end();
        }
    )    
}

//Inserir
function inserir(aluno, callback) {
    const cliente = new Client(conexao);
    cliente.connect();

    const sql = "INSERT INTO tabela_aluno(matricula, nome_aluno, curso) VALUES ($1, $2, $3) RETURNING *";
    const values = [aluno.matricula, aluno.nome_aluno, aluno.curso];

    cliente.query(sql, values, 
        function (err, res){
            console.log(err);
            if(err){
                console.log(err);
                callback(erroBancoDados, undefined);
            }
            else {
                callback(undefined, res.rows[0]);
            }
            cliente.end();
        })
}



//Buscar Matricula
function buscarPorMatricula(matricula, callback){
    const cliente = new Client(conexao);
    cliente.connect();

    const sql = "SELECT * FROM tabela_aluno WHERE matricula=$1";
    const values = [matricula];

    cliente.query(sql, values,
        function (err, res) {
            if(err) {
                console.log(err);
                callback(erroBancoDados, undefined);                
            }
            else if (res.rows && res.rows.length > 0) {
                let aluno = res.rows[0];
                callback(undefined, aluno);
            }
            else {
                callback(erroAlunoNaoEncontrado, undefined);
            }

            cliente.end();
        }
    )    
}


//Deletar
function deletar(matricula, callback) {
    const cliente = new Client(conexao);
    cliente.connect();
    const sql = "DELETE FROM tabela_aluno WHERE matricula=$1 RETURNING *"
    const values = [matricula];
    cliente.query(sql, values, function(err, res) {
        if(err) {
            console.log(err);
            callback(erroBancoDados, undefined);                
    }
        else if (res.rows && res.rows.length > 0) {
            let aluno = res.rows[0];
            callback(undefined, aluno);
        }
        else {
            callback(erroAlunoNaoEncontrado, undefined);
    }
        cliente.end();        
    })
}

//Atualizar
function atualizar(matricula,aluno, callback) {
    const cliente = new Client(conexao);
    cliente.connect();
    const sql = "UPDATE tabela_aluno SET nome_aluno=$1, curso=$2 WHERE matricula=$3 RETURNING *"    
    const values = [aluno.nome_aluno, aluno.curso, matricula];
    cliente.query(sql, values, function(err, res) {
        if(err) {
            console.log(err);
            callback(erroBancoDados, undefined);                
        }
        else if (res.rows && res.rows.length > 0) {
            let aluno = res.rows[0];
            callback(undefined, aluno);
        }
        else {
            callback(erroAlunoNaoEncontrado, undefined);
        }
        cliente.end();        
    })
}


module.exports = {
    listar, inserir, buscarPorMatricula, deletar, atualizar
}