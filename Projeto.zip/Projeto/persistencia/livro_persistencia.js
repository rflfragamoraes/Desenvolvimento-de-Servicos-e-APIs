const {Client} = require('pg');

const erroBancoDados = { 
    mensagem: "Erro de conexao no BD",
    status_erro: 500
};


const erroLivroNaoEncontrado = {
    mensagem: "Livro nao encontrado",
    status_erro: 404
};


const conexao = {
    host: 'localhost',
    port: 5432,
    user: 'postgres',
    password: 'postgres',
    database: 'crud_biblioteca'
};

// Listar
function listar(callback) {
    const cliente = new Client(conexao);
    cliente.connect();
    
    const sql = "SELECT * FROM tabela_livro";
    cliente.query(sql, 
        function (err, res) {
            if(err) {
                console.log(err);
                callback(erroBancoDados, undefined);
            }
            else {
                let livro = res.rows;
                callback(undefined, livro);     
            }
            cliente.end();
        }
    )    
}

//Inserir
function inserir(livro, callback) {
    const cliente = new Client(conexao);
    cliente.connect();
    const sql = "INSERT INTO tabela_livro(codigo, nome_livro, autor, quantidade) VALUES ($1, $2, $3, $4) RETURNING *";
    const values = [livro.codigo, livro.nome_livro, livro.autor, livro.quantidade];

    cliente.query(sql, values, 
        function (err, res){
            console.log(err);
            if(err){
                console.log(err);
                callback(erroBancoDados, undefined);
            }
            else {
                callback(undefined, res.rows[0]);
            }
            cliente.end();
        })
}



//Buscar Matricula
function buscarPorCodigo(codigo, callback){
    const cliente = new Client(conexao);
    cliente.connect();    
    const sql = "SELECT * FROM tabela_livro WHERE codigo=$1";
    const values = [codigo];

    cliente.query(sql, values,
        function (err, res) {
            if(err) {
                callback(err.message, undefined);                
            }
            else if (res.rows && res.rows.length > 0) {
                let livro = res.rows[0];
                callback(undefined, livro);
            }
            else {
                callback(erroLivroNaoEncontrado, undefined);
            }
            cliente.end();
        }
    )    
}

//Deletar
function deletar(codigo, callback) {
    const cliente = new Client(conexao);
    cliente.connect();
    const sql = "DELETE FROM tabela_livro WHERE codigo=$1 RETURNING *"
    const values = [codigo];

    cliente.query(sql, values, function(err, res) {
        if(err) {
            callback(err.message, undefined);                
        }
        else if (res.rows && res.rows.length > 0) {
            let livro = res.rows[0];
            callback(undefined, livro);
        }
        else {
            callback(erroLivroNaoEncontrado, undefined);
        }
        cliente.end();        
    })

}

//Atualizar
/*function atualizar(id,produto, callback) {
    const cliente = new Client(conexao);
    cliente.connect();

    const sql = "UPDATE produtos SET nome=$1, preco=$2 WHERE id=$3 RETURNING *"
    const values = [produto.nome, produto.preco, id];

    cliente.query(sql, values, function(err, res) {
        if(err) {
            callback(err.message, undefined);                
        }
        else if (res.rows && res.rows.length > 0) {
            let produto = res.rows[0];
            callback(undefined, produto);
        }
        else {
            callback(erroLivroNaoEncontrado, undefined);
        }

        cliente.end();        
    })
}*/


module.exports = {
    listar, inserir, buscarPorCodigo, deletar
}