const express = require('express');
const alunoNegocio = require('./negocio/aluno_negocio.js');
const livroNegocio = require('./negocio/livro_negocio.js');
const alunoController = require('./controller/alunoController.js');
const livroController = require('./controller/livroController.js');
const app = express();
const port = 3000;


app.use(express.json());
app.use(express.urlencoded({ extended: true }));


//////////////////////////////////////////////
//API Aluno
//////////////////////////////////////////////

//Listar
app.get('/api_aluno/listar', alunoController.listar);

//Inserir
app.post('/api_aluno/inserir', alunoController.inserir);  
  
// Buscar matricula
app.get('/api_aluno/buscar/:matricula', alunoController.buscarPorMatricula);

//Deletar
app.delete('/api_aluno/deletar/:matricula', alunoController.deletar);

//Atualizar
app.put('/api_aluno/atualizar/:matricula', alunoController.atualizar);


//////////////////////////////////////////////
//API Livro
//////////////////////////////////////////////

//Listar
app.get('/api_livro/listar', livroController.listar)


  //Inserir
  app.post('/api_livro/inserir', livroController.inserir)


  //Buscar codigo
  app.get('/api_livro/buscar:codigo', (req, res) => {
      const codigo = req.params.codigo;
      livroNegocio.buscarPorCodigo(codigo, function (err, livro){
        if(err) {
          res.status(err.numero).json({erro: err.mensagem});
        }
        else {
          res.json(livro);
        }
      });
  })
  
  
  //Deletar
  app.delete('/api_livro/deletar/:codigo', livroController.deletar);

  
  //atualizar
  app.put('/api_livro/atualizar:codigo', (req, res) => {
      const cod = req.params.codigo;
      const livro = req.body;
      const data = {};
      data.msg = `O livro codigo=${cod}, nome${livro.nome} foi atualizado`;
      res.json(data);
  
  })



app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})