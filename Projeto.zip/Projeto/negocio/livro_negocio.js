const livroRepositorio = require('../persistencia/livro_persistencia.js')


function listar (callback) {
    livroRepositorio.listar(callback);
}


function inserir (livro, callback) {
    if(!livro.codigo || !livro.nome_livro || !livro.autor || !livro.quantidade ){
        const erro = { 
            mensagem: "Campo codigo, nome do livro, autor ou quantidade esta vazio!",
            status_erro: 400
        };
        callback(erro, undefined)
    }
    else {
        livroRepositorio.inserir(livro, callback);
    }  
}

function buscarPorCodigo(codigo, callback){
    if(!codigo || isNaN(codigo)){
        const err = { 
            mensagem: "Identificador Invalido!",
            numero: 400
        }
        callback(err, undefined);
    }
    else { 
        livroRepositorio.buscarPorCodigo(codigo, callback);
    }
}


function deletar(codigo, callback) {
    if(!codigo || isNaN(codigo)){
        const erro = { 
            mensagem: "Identificador Invalido!",
            numero: 400
        }
        callback(erro, undefined);
    }
    else {
        livroRepositorio.deletar(codigo,callback);
    }
}

function atualizar(codigo, livro, callback) {
    if(!codigo || isNaN(codigo)){
        const err = { 
            mensagem: "Identificador Invalido!",
            numero: 400
        }
        callback(err, undefined);
    }
    else if(!livro || !livro.nome_livro || !livro.autor || !livro.quantidade) {
        const err = { 
            mensagem: "Os campos nome do livro, autor e quantidade devem ser preenchidos!",
            numero: 400
        };
        callback(err, undefined)
    }
    else { 
        livroRepositorio.atualizar(codigo, livro, callback);
    }

}


module.exports = {
    inserir, listar, buscarPorCodigo, deletar, atualizar
}