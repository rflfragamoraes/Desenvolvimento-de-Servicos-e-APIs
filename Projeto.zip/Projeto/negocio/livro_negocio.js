const livroRepositorio = require('../persistencia/livro_persistencia.js')


function listar (callback) {
    livroRepositorio.listar(callback);
}


function inserir (livro, callback) {
    if(!livro.codigo || !livro.nome_livro || !livro.autor || !livro.quantidade ){
        const erro = { 
            mensagem: "Campo codigo, nome do livro, autor ou quantidade esta vazio!",
            status_erro: 400
        };
        callback(erro, undefined)
    }
    else {
        livroRepositorio.inserir(livro, callback);
    }  
}

function buscarPorCodigo(codigo, callback){
    if(!codigo || isNaN(codigo)){
        const erro = { 
            mensagem: "Identificador Invalido!",
            numero: 400
        }
        callback(erro, undefined);
    }
    else { 
        livroRepositorio.buscarPorCodigo(codigo, callback);
    }
}

function deletar(codigo, callback) {
    if(!codigo || isNaN(codigo)){
        const erro = { 
            mensagem: "Identificador Invalido!",
            numero: 400
        }
        callback(erro, undefined);
    }
    else {
        livroRepositorio.deletar(codigo,callback);
    }
}


module.exports = {
    inserir, listar, buscarPorCodigo, deletar
}