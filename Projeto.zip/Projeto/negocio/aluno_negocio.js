const alunoRepositorio = require('../persistencia/aluno_persistencia.js')


function listar (callback) {
    alunoRepositorio.listar(callback);
}


function inserir (aluno, callback) {
    if(!aluno.matricula || !aluno.nome_aluno || !aluno.curso){
        const erro = { 
            mensagem: "Campo matricula, nome do aluno ou curso esta vazio!",
            status_erro: 400
        };
        callback(erro, undefined)
    }
    else {
        alunoRepositorio.inserir(aluno, callback);
    }  
}


function buscarPorMatricula(matricula, callback){
    if(!matricula || isNaN(matricula)){
        const err = { 
            mensagem: "Identificador Invalido!",
            numero: 400
        }
        callback(err, undefined);
    }
    else { 
        alunoRepositorio.buscarPorMatricula(matricula, callback);
    }
}

function deletar(matricula, callback) {
    if(!matricula || isNaN(matricula)){
        const erro = { 
            mensagem: "Identificador Invalido!",
            numero: 400
        }
        callback(erro, undefined);
    }
    else {
        alunoRepositorio.deletar(matricula,callback);
    }
}

function atualizar(matricula, aluno, callback) {
    if(!matricula || isNaN(matricula)){
        const err = { 
            mensagem: "Identificador Invalido!",
            numero: 400
        }
        callback(err, undefined);
    }
    else if(!aluno || !aluno.nome_aluno || !aluno.curso) {
        const err = { 
            mensagem: "Os campos nome do aluno e curso devem ser preenchidos!",
            numero: 400
        };
        callback(err, undefined)
    }
    else { 
        alunoRepositorio.atualizar(matricula, aluno, callback);
    }

}



module.exports = {
    inserir, listar, buscarPorMatricula, deletar, atualizar
}